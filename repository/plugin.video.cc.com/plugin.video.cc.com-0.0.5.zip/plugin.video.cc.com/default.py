# coding: utf-8
# author: nixxo
from libs.main import ComedyCentral

cc = ComedyCentral()
cc.main()

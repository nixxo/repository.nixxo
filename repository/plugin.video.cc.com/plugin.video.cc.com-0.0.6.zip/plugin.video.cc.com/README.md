# plugin.video.cc.com
Comedy Central Kodi Plugin

This Kodi addons scapes the website of [Comedy Central](https://www.cc.com) and extracts video url freely accessiblle on the website.

It uses a modified version on [yt-dlp](https://github.com/yt-dlp/yt-dlp) (a youtube-dl fork) that is been cleaned and shrinked to be compatible with only cc.com content and nothing else.

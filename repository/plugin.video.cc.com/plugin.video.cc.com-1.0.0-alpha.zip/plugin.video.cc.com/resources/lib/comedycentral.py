# -*- coding: utf-8 -*-
import datetime, re, json, socket, traceback
import xbmc, xbmcgui
from phate89lib import kodiutils

import urllib.request as urllib2

from YDStreamExtractor import getVideoInfo
from simplecache import SimpleCache


class CC(object):
    TIMEOUT = 15
    QUALITY = int(kodiutils.getSetting('Quality'))
    PTVL_RUNNING = xbmcgui.Window(10000).getProperty('PseudoTVRunning') == 'True'
    DEBUG = kodiutils.getSetting('Debug') == 'true'
    BASE_URL = 'https://www.cc.com'
    LOGO_URL = 'https://dummyimage.com/512x512/035e8b/FFFFFF.png&text=%s'
    ICON = kodiutils.ADDON.getAddonInfo('icon')
    FANART = kodiutils.ADDON.getAddonInfo('fanart')
    MAIN_MENU = [{
            'label': kodiutils.LANGUAGE(30004),
            'params': {'url': BASE_URL + '/shows', 'mode': 'SHOWS'},
        },
        {
            'label': kodiutils.LANGUAGE(30005),
            'params': {
                'url': BASE_URL + '/topic/stand-up',
                'mode': 'GENERIC',
                'name': kodiutils.LANGUAGE(30005),},
        },
        {
            'label': kodiutils.LANGUAGE(30006),
            'params': {
                'url': BASE_URL + '/topic/digital-originals',
                'mode': 'GENERIC',
                'name': kodiutils.LANGUAGE(30006),
            },
        },
    ]
    PAGES_CRUMB = ['topic', 'collections', 'shows']

    def __init__(self):
        self.log('__init__')
        socket.setdefaulttimeout(self.TIMEOUT)
        self.cache = SimpleCache()

    def log(self, msg, level=xbmc.LOGDEBUG):
        if self.DEBUG is False and level != xbmc.LOGERROR:
            return
        if level == xbmc.LOGERROR:
            msg += ' ,' + traceback.format_exc()
        xbmc.log('%s - %s - %s' % (kodiutils.ID, kodiutils.VERSION, msg), level)

    def openURL(self, url):
        self.log('openURL, url = %s' % url)
        try:
            cacheresponse = self.cache.get('%s.openURL, url = %s' % (kodiutils.NAME, url))
            if not cacheresponse:
                request = urllib2.Request(url)              
                response = urllib2.urlopen(request, timeout=self.TIMEOUT).read()
                self.cache.set(
                    '%s.openURL, url = %s' % (kodiutils.NAME, url),
                    response,
                    expiration=datetime.timedelta(days=1))
            return self.cache.get('%s.openURL, url = %s' % (kodiutils.NAME, url))
        except Exception as e:
            self.log("openURL Failed! " + str(e), xbmc.LOGERROR)
            kodiutils.notify(kodiutils.LANGUAGE(30003))
            kodiutils.endScript()

    def createURL(self, url):
        if url.startswith('http'):
            return url
        return self.BASE_URL + url

    def createInfoArt(self, image=False, fanart=False):
        self.log('createInfoArt, image = %s; fanart = %s' % (str(image), str(fanart)))
        thumb = ('%s&width=512&crop=false' % image) if image else None
        return {
            'thumb': thumb,
            'poster': thumb,
            'fanart': (image or thumb) if fanart else self.FANART,
            'icon': self.ICON,
            'logo': self.ICON
        }

    def loadJsonData(self, url):
        self.log('loadJsonData, url = %s' % url)
        response = self.openURL(url)
        if len(response) == 0:
            return
        response = response.decode('utf-8')

        try:
            # try if the file is json
            items = json.loads(response)
        except:
            # file is html
            try:
                src = re.search('window\\.__DATA__\\s*=\\s*(.+?);\\s*window\\.__PUSH_STATE__', response).group(1)
                items = json.loads(src)
            except Exception as e:
                kodiutils.notify('NO JSON DATA FOUND')
                self.log('loadJsonData, NO JSON DATA FOUND' + str(e), xbmc.LOGERROR)
                kodiutils.endScript()

        return items

    def extractItemType(self, data, type, ext):
        self.log('extractItemType, type = %s; ext = %s' % (type, ext))
        items = [x.get(ext) for x in data if x.get('type') == type]
        return items[0] if len(items) > 0 and isinstance(items[0], list) else items

    def extractItems(self, data):
        self.log('extractItems')
        # extract items from the page json
        items = []
        for item in data or []:
            if item.get('type') == 'LineList':
                items.extend(item['props'].get('items') or [])
                items.extend([item['props'].get('loadMore')] or [])
            if item.get('type') == 'Fragment':
                items.extend(self.extractItems(item.get('children')) or [])
        self.log('extractItems, items extracted = %d' % len(items))
        return items

    def getMainMenu(self):
        self.log('getMainMenu')
        return self.MAIN_MENU

    def showsList(self, url):
        self.log('showsList, url = %s' % url)
        items = self.loadJsonData(url)
        if 'items' in items:
            items['items'].extend([items.get('loadMore')] or [])
            items = items['items']
        else:
            items = self.extractItemType(
                items.get('children') or [],
                'MainContainer',
                'children')
            items = self.extractItems(items)

        for item in items:
            if 'loadingTitle' in item:
                yield {
                    'label': item['title'],
                    'params': {
                        'mode': 'SHOWS',
                        'url': self.createURL(item['url'])
                    },
                }
            else:
                label = item['meta']['header']['title']
                yield {
                    'label': label,
                    'params': {
                        'mode': 'GENERIC',
                        'url': self.createURL(item['url']),
                        'name': label,
                    },
                    'videoInfo': {
                        'mediatype': 'tvshows',
                        'title': label,
                        'tvshowtitle': label,
                    },
                    'arts': self.createInfoArt(item['media']['image']['url'], False),
                }

    def genericList(self, name, url):
        self.log('genericList, name = %s, url = %s' % (name, url))
        try:
            mtc = re.search(r'(/%s/)' % '/|/'.join(self.PAGES_CRUMB), url).group(1)
            name_of_method = "load%s" % mtc.strip('/').capitalize()
            method = getattr(self, name_of_method)
            self.log('genericList, using method = %s' % str(method))
            yield from method(name, url)
        except:
            self.log('genericList, URL not supported')
            return

    def loadShows(self, name, url, season=False):
        self.log('loadShows, name = %s, url = %s, season = %s' % (
            name, url, str(season)))
        items = self.loadJsonData(url)
        if not season:
            items = self.extractItemType(
                items.get('children') or [], 'MainContainer', 'children')
            items = self.extractItemType(items, 'SeasonSelector', 'props')
            # check if no season selector is present
            # or season selector is empty
            if len(items) == 0 or (
                    len(items[0]['items']) == 1 and not items[0]['items'][0].get('url')):
                # and load directly the show
                yield from self.loadShows(name, url, True)
                return
        else:
            items = self.extractItemType(
                items.get('children') or [], 'MainContainer', 'children')
            items = self.extractItemType(items, 'LineList', 'props')
            items = self.extractItemType(items, 'video-guide', 'filters')
        
        items = items[0]['items']
        # check if there is only one item
        if len(items) == 1:
            # and load it directly
            yield from self.loadItems(
                name, self.createURL(items[0].get('url') or url))
        else:
            for item in items:
                label = item['label']
                yield {
                    'label': label,
                    'params': {
                        'mode': 'EPISODES' if season else 'SEASON',
                        'url': self.createURL(item.get('url') or url),
                        'name': name,
                    },
                    'videoInfo': {
                        'mediatype': 'season',
                        'title': label,
                        'tvshowtitle': name
                    },
                    'arts': self.createInfoArt(),
                }

    def loadItems(self, name, url):
        self.log('loadItems, name = %s, url = %s' % (name, url))
        items = self.loadJsonData(url)
        
        for item in items.get('items') or []:
            try:
                sub = item['meta'].get('subHeader')
                if isinstance(item['meta']['header']['title'], str):
                    label = item['meta']['header']['title']
                else:
                    label = item['meta']['header']['title'].get('text') or ''
                label = '%s - %s' % (label, sub) if sub else label
            except:
                label = 'NO TITLE'
            try:
                season, episode = re.search(
                    r'season\s*(\d+)\s*episode\s*(\d+)\s*',
                    item['meta']['itemAriaLabel'],
                    re.IGNORECASE).groups()
            except:
                season, episode = None, None

            yield {
                'label': label,
                'params': {
                    'mode': 'PLAY',
                    'url': self.createURL(item['url']),
                    'name': label,
                },
                'videoInfo': {
                    'mediatype': 'video',
                    'title': sub or label,
                    'tvshowtitle': name,
                    'plot': item['meta']['description'],
                    'season': season,
                    'episode': episode,
                },
                'arts': self.createInfoArt(item['media']['image']['url'], True),
                'playable': True,
            }

        if items.get('loadMore'):
            label = items['loadMore']['title']
            yield {
                'label': kodiutils.LANGUAGE(30007),
                'params': {
                    'mode': 'EPISODES',
                    # replace necessary to encode only ":"
                    'url': self.createURL(items['loadMore']['url'].replace(':', '%3A')),
                    'name': name,
                },
                'videoInfo': {
                    'mediatype': 'tvshows',
                    'title': label,
                    'tvshowtitle': name
                },
                'arts': self.createInfoArt(),
            }

    def loadCollections(self, name, url):
        # TODO
        pass

    def loadTopic(self, name, url):
        self.log('loadTopic, name = %s, url = %s' % (name, url))
        items = self.loadJsonData(url)
        items = self.extractItemType(
            items.get('children') or [],
            'MainContainer',
            'children')
        items = self.extractItems(items)

        for item in items:
            if not item or item.get('cardType') != 'series':
                continue
            label = item['title']
            playable = not any(('/%s/' % x) in item['url'] for x in self.PAGES_CRUMB)
            yield {
                'label': label,
                'params': {
                    'mode': 'PLAY' if playable else 'GENERIC',
                    'url': self.createURL(item['url']),
                    'name': label,
                },
                'videoInfo': {
                    'mediatype': 'video' if playable else 'tvshow',
                    'title': label,
                    'tvshowtitle': item['meta']['label'],
                },
                'arts': self.createInfoArt(item['media']['image']['url'], playable),
                'playable': playable,
            }

    def getPlayItems(self, name, url):
        self.log('getPlayItems, name = %s, url = %s' % (name, url))
        info = getVideoInfo(url, self.QUALITY, True)
        if info is None:
            return
        info = info.streams()
        self.log('getPlayItems, streams number: %d' % len(info))
        for videos in info or []:
            vidIDX = videos['idx']
            label = '%s - Act %d' % (name, vidIDX+1)
            if len(info) == 1:
                label = name
            subs = None
            try:
                if 'subtitles' in videos['ytdl_format']:
                    subs = [x['url'] for x in videos['ytdl_format']['subtitles'].get('en', '') if 'url' in x and x['ext'] == 'vtt']
            except:
                pass
            yield {
                'idx': videos['idx'],
                'url': videos['xbmc_url'],
                'label': label,
                'videoInfos': {
                    'mediatype': 'video',
                    'title': label,
                },
                'subs': subs,
            }

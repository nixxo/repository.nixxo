# -*- coding: utf-8 -*-
from resources.lib.comedycentral import CC
from phate89lib import kodiutils, staticutils
import xbmc


class ComedyCentral(object):

    def __init__(self):
        self.cc = CC()  

    def addItems(self, items):
        episodes = False
        for item in items or []:
            episodes = any([item.get('playable'), episodes])
            kodiutils.addListItem(
                item['label'],
                item['params'],
                arts=item.get('arts'),
                videoInfo=item.get('videoInfo'),
                isFolder=False if item.get('playable') else True,
            )
        if episodes:
            kodiutils.setContent('episodes')

    def main(self):
        params = staticutils.getParams()
        if 'mode' in params:
            if params['mode'] == 'SHOWS':
                shows = self.cc.showsList(params['url'])
                self.addItems(shows)
                kodiutils.setContent('tvshows')

            elif params['mode'] == 'GENERIC':
                generic = self.cc.genericList(params['name'], params['url'])
                self.addItems(generic)

            elif params['mode'] == 'SEASON':
                show = self.cc.loadShows(params['name'], params['url'], True)
                self.addItems(show)

            elif params['mode'] == 'EPISODES':
                episodes = self.cc.loadItems(params['name'], params['url'])
                self.addItems(episodes)
                kodiutils.setContent('episodes')

            elif params['mode'] == 'PLAY':
                if self.cc.PTVL_RUNNING:
                    return kodiutils.notify(kodiutils.LANGUAGE(30007))
                playItems = self.cc.getPlayItems(params['name'], params['url'])
                plst = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                plst.clear()
                xbmc.sleep(200)
                for item in playItems:
                    vidIDX = item['idx']
                    liz = kodiutils.createListItem(
                        label=item['label'], path=item['url'],
                        videoInfo=item['videoInfos'], subs=item['subs'],
                        isFolder=False)
                    if vidIDX == 0:
                        kodiutils.setResolvedUrl(item=liz, exit=False)
                    plst.add(item['url'], liz, vidIDX)
                plst.unshuffle()

        else:
            menu = self.cc.getMainMenu()
            for item in menu or []:
                kodiutils.addListItem(
                    item['label'],
                    item['params'],
                    isFolder=True)

        kodiutils.endScript()

# -*- coding: utf-8 -*-
from resources.main import ComedyCentral

cc = ComedyCentral()
cc.main()

#entrypoint
#if __name__ == '__main__':
#    from resources.lib import comedycentral
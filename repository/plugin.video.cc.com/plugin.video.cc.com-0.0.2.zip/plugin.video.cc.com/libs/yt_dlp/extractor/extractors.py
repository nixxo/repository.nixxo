# flake8: noqa
from __future__ import unicode_literals

from .comedycentral import (
    ComedyCentralIE,
    ComedyCentralMgidIE,
)

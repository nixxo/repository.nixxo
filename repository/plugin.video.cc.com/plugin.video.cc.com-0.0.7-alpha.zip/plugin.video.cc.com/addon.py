# author: nixxo
from resources.lib.main import ComedyCentral

cc = ComedyCentral()
cc.main()

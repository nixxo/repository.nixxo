from resources.lib import main

main.main()

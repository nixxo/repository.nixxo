# plugin.video.vvvvid
Xbmc addon to view vvvvid.it content.
Credits to narsus81 for pull request to fix m3u and f4m handling.

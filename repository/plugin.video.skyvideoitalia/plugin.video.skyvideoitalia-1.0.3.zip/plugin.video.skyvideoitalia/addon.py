# -*- coding: utf-8 -*-
from resources.lib.main import SkyVideoItalia

sky = SkyVideoItalia()
sky.main() 

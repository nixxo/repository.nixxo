# -*- coding: utf-8 -*-
from resources.main import SkyVideoItalia

sky = SkyVideoItalia()
sky.main()

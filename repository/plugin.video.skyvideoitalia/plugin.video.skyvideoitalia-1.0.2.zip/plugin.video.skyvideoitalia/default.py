# -*- coding: utf-8 -*-
from libs.main import SkyVideoItalia

sky = SkyVideoItalia()
sky.main()

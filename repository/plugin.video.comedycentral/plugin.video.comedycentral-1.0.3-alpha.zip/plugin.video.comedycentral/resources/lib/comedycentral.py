#   Copyright (C) 2018 Lunatixz
#
#
# This file is part of Comedy Central.
#
# Comedy Central is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Comedy Central is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Comedy Central.  If not, see <http://www.gnu.org/licenses/>.

# -*- coding: utf-8 -*-
import sys, datetime, re, traceback, json, socket
import xbmc, xbmcgui, xbmcplugin, xbmcaddon

import urllib.request as urllib2
import urllib.parse as urlparse
import collections

from YDStreamExtractor import getVideoInfo
from simplecache import SimpleCache

import web_pdb

# Plugin Info
ADDON_ID      = 'plugin.video.comedycentral'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
SETTINGS_LOC  = REAL_SETTINGS.getAddonInfo('profile')
ADDON_PATH    = REAL_SETTINGS.getAddonInfo('path')
ADDON_VERSION = REAL_SETTINGS.getAddonInfo('version')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')
LANGUAGE      = REAL_SETTINGS.getLocalizedString

## GLOBALS ##
TIMEOUT       = 15
CONTENT_TYPE  = 'files'
DEBUG         = REAL_SETTINGS.getSetting('Enable_Debugging') == 'true'
QUALITY       = int(REAL_SETTINGS.getSetting('Quality'))
PTVL_RUNNING  = xbmcgui.Window(10000).getProperty('PseudoTVRunning') == 'True'
BASE_URL      = 'https://www.cc.com'
LOGO_URL      = 'https://dummyimage.com/512x512/035e8b/FFFFFF.png&text=%s'
MAIN_MENU     = [
    (LANGUAGE(30004), BASE_URL + '/shows', 'SHOWS'),
    (LANGUAGE(30005), BASE_URL + '/topic/stand-up', 'GENERIC'),
    (LANGUAGE(30009), BASE_URL + '/topic/digital-originals', 'GENERIC')
]
PAGES_CRUMB   = ['topic', 'collections', 'shows']


def log(msg, level=xbmc.LOGDEBUG):
    if DEBUG is False and level != xbmc.LOGERROR:
        return
    if level == xbmc.LOGERROR:
        msg += ' ,' + traceback.format_exc()
    xbmc.log('%s-%s-%s' % [ADDON_ID, ADDON_VERSION, msg], level)


def getParams():
    return dict(urlparse.parse_qsl(sys.argv[2][1:]))


class CC(object):
    def __init__(self):
        log('__init__')
        socket.setdefaulttimeout(TIMEOUT)
        self.cache = SimpleCache()

    def openURL(self, url):
        log('openURL, url = ' + str(url))
        try:
            cacheresponse = self.cache.get('%s.openURL, url = %s' % (ADDON_NAME, url))
            if not cacheresponse:
                request = urllib2.Request(url)              
                response = urllib2.urlopen(request, timeout=TIMEOUT).read()
                self.cache.set(
                    '%s.openURL, url = %s' % (ADDON_NAME, url),
                    response,
                    expiration=datetime.timedelta(days=1))
            return self.cache.get('%s.openURL, url = %s' % (ADDON_NAME, url))
        except Exception as e:
            log("openURL Failed! " + str(e), xbmc.LOGERROR)
            if str(e).startswith('HTTP Error 500'):
                return ''
            xbmcgui.Dialog().notification(ADDON_NAME, LANGUAGE(30001), ICON, 4000)
            return ''

    def createURL(self, url):
        if url.startswith('http'):
            return url
        return BASE_URL + url

    def createInfoArt(self, image=False, fanart=False):
        thumb = ('%s&width=512&crop=false' % image) if image else None
        return {
            'thumb': thumb,
            'poster': thumb,
            'fanart': image if fanart else FANART,
            'icon': ICON,
            'logo': ICON
        }

    def loadJsonData(self, url):
        # web_pdb.set_trace()
        log('loadjson')
        response = self.openURL(url)
        if len(response) == 0:
            return
        response = response.decode('utf-8').replace('\\u002F', '/')

        try:
            # try if the file is json
            items = json.loads(response)
        except:
            # file is html
            try:
                src = re.search('window\\.__DATA__\\s*=\\s*(.+?);\\s*window\\.__PUSH_STATE__', response).group(1)
                items = json.loads(src)
            except:
                return xbmcgui.Dialog().notification(ADDON_NAME, 'NO JSON DATA FOUND', ICON, 6000)

        return items

    def extractItemType(self, data, type, ext):
        # web_pdb.set_trace()
        items = []
        for item in data or []:
            if item.get('type') == type and ext in item:
                items.extend(
                    item[ext] if isinstance(item[ext], list) else [item[ext]])
        return items

    def extractItems(self, data):
        # web_pdb.set_trace()
        items = []
        for item in data or []:
            if item.get('type') == 'LineList':
                items.extend(item['props'].get('items') or [])
            if item.get('type') == 'Fragment':
                items.extend(self.extractItems(item.get('children')) or [])
        return items

    def buildMenu(self, items):
        for item in items:
            self.addDir(*item)

    def listShows(self, name, url):
        log('listShows')
        # web_pdb.set_trace()
        items = self.loadJsonData(url)
        items = self.extractItemType(
            items.get('children') or [],
            'MainContainer',
            'children')
        items = self.extractItems(items)

        for item in items:
            label = item['meta']['header']['title']
            infoLabels = {
                'mediatype': 'tvshows',
                'label': label,
                'title': label,
                'tvshowtitle': label
            }
            self.addDir(
                label,
                self.createURL(item['url']),
                'GENERIC',
                infoLabels,
                self.createInfoArt(item['media']['image']['url'], False)
            )

    def loadShows(self, name, url, season=False):
        # web_pdb.set_trace()
        log('browse, ' + name)
        items = self.loadJsonData(url)
        if not season:
            items = self.extractItemType(
                items.get('children') or [], 'MainContainer', 'children')
            items = self.extractItemType(items, 'SeasonSelector', 'props')
            # check if no season selector is present
            if len(items) == 0:
                self.loadShows(name, url, True)
                return
        else:
            items = self.extractItemType(
                items.get('children') or [], 'MainContainer', 'children')
            items = self.extractItemType(items, 'LineList', 'props')
            items = self.extractItemType(items, 'video-guide', 'filters')
        
        items = items[0]['items']
        if len(items) == 1:
            # if the season has a single playlist load it
            uri = BASE_URL + items[0]['url'].replace(':', '%3A') if items[0]['url'] else url
            self.browseItems(name, uri)
        else:
            for item in items:
                label = item['label']
                infoLabels = {
                    'mediatype': 'tvshows',
                    'label': label,
                    'title': label,
                    'tvshowtitle': name
                }
                uri = self.createURL(item['url'].replace(':', '%3A') if item['url'] else url)
                self.addDir(
                    name,
                    uri,
                    'EPISODES' if season else 'SEASON',
                    infoLabels,
                    self.createInfoArt()
                )

    def loadCollections(self, name, url):
        web_pdb.set_trace()
        pass

    def loadTopic(self, name, url):
        log('topic')
        # web_pdb.set_trace()
        items = self.loadJsonData(url)
        items = self.extractItemType(
            items.get('children') or [],
            'MainContainer',
            'children')
        items = self.extractItems(items)

        episodes = False
        for item in items:
            label = item['title']
            infoLabels = {
                'mediatype': 'tvshows',
                'label': label,
                'title': label,
                'tvshowtitle': item['meta']['label']
            }
            if any(('/%s/' % x) in item['url'] for x in PAGES_CRUMB):
                self.addDir(
                    label,
                    self.createURL(item['url']),
                    'GENERIC',
                    infoLabels,
                    self.createInfoArt(item['media']['image']['url'], True)
                )
            else:
                episodes = True
                self.addLink(
                    label,
                    self.createURL(item['url']),
                    'PLAY',
                    infoLabels,
                    self.createInfoArt(item['media']['image']['url'], True)
                )
        xbmcplugin.setContent(int(sys.argv[1]), 'episodes' if episodes else 'files')

    def loadGeneric(self, name, url):
        # web_pdb.set_trace()
        mtc = re.search(r'(/%s/)' % '/|/'.join(PAGES_CRUMB), url).group(1)
        name_of_method = "load%s" % mtc.strip('/').capitalize()
        method = getattr(self, name_of_method)
        return method(name, url)

    def browseItems(self, name, url):
        # web_pdb.set_trace()
        log('browse, ' + name)
        items = self.loadJsonData(url)
        
        for item in items.get('items') or []:
            # web_pdb.set_trace()
            try:
                sub = item['meta'].get('subHeader')
                if isinstance(item['meta']['header']['title'], str):
                    label = item['meta']['header']['title']
                else:
                    label = item['meta']['header']['title'].get('text') or ''
                label = '%s - %s' % (label, sub) if sub else label
            except:
                label = 'NO TITLE'
            try:
                season, episode = re.search(
                    r'season\s*(\d+)\s*episode\s*(\d+)\s*',
                    item['meta']['itemAriaLabel'],
                    re.IGNORECASE).groups()
            except:
                season, episode = None, None

            infoLabels = {
                'mediatype': 'video',
                'label': label,
                'title': sub or label,
                'tvshowtitle': name,
                'plot': item['meta']['description'],
                'season': season,
                'episode': episode,
                'aired': item['meta']['date']
            }
            '''
            try: aired = datetime.datetime.fromtimestamp(float(video['airDate']))
            except: aired = datetime.datetime.now()
            try: duration = video['duration']
            except: duration = 0
            infoLabels = {"mediatype":"episode","label":label ,"title":label,"TVShowTitle":show,"plot":plot,"aired":aired.strftime('%Y-%m-%d'),"duration":duration,}
            '''
            self.addLink(
                label,
                self.createURL(item['url']),
                'PLAY',
                infoLabels,
                self.createInfoArt(item['media']['image']['url'], True)
            )
        if items.get('loadMore'):
            label = items['loadMore']['title']
            infoLabels = {
                'mediatype': 'tvshows',
                'label': label,
                'title': label,
                'tvshowtitle': name
            }
            self.addDir(
                name,
                self.createURL(items['loadMore']['url'].replace(':', '%3A')),
                'EPISODES',
                infoLabels,
                self.createInfoArt()
            )
        xbmcplugin.setContent(int(sys.argv[1]), 'episodes')

    def playItem(self, name, url):
        log('playVideo')
        # web_pdb.set_trace()
        info = getVideoInfo(url, QUALITY, True)
        if info is None:
            return
        info = info.streams()
        if len(info) > 1:
            if PTVL_RUNNING:
                return xbmcgui.Dialog().notification(
                    ADDON_NAME, LANGUAGE(30007), ICON, 4000)
            info = sorted(info, key=lambda x: x['idx'])
            plst = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            plst.clear()
            xbmc.sleep(200)
            for videos in info:
                vidIDX = videos['idx']
                url = videos['xbmc_url']
                liz = xbmcgui.ListItem(videos['title'], path=url)
                try: 
                    if 'subtitles' in videos['ytdl_format']:
                        liz.setSubtitles([x['url'] for x in videos['ytdl_format']['subtitles'].get('en', '') if 'url' in x])
                except:
                    pass
                plst.add(url, liz, vidIDX)
                if vidIDX == 0:
                    xbmcplugin.setResolvedUrl(
                        int(sys.argv[1]), True, liz) 
            plst.unshuffle()
        else:
            liz = xbmcgui.ListItem(info[0]['title'], path=info[0]['xbmc_url'])
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

    def addLink(self, name, u, mode, infoList=False, infoArt=False, total=0):
        name = name.encode("utf-8")
        log('addLink, name = %s', name)
        liz = xbmcgui.ListItem(name)
        liz.setProperty('IsPlayable', 'true')
        if infoList is False:
            liz.setInfo(type="Video",
                        infoLabels={"mediatype": "video",
                                    "label": name,
                                    "title": name})
        else:
            liz.setInfo(type="Video", infoLabels=infoList)
        if infoArt is False:
            liz.setArt({'thumb': ICON, 'fanart': FANART})
        else:
            liz.setArt(infoArt)
        u = "%s?url=%s&mode=%s&name=%s" % (
            sys.argv[0], urlparse.quote_plus(u),
            str(mode), urlparse.quote_plus(name))
        xbmcplugin.addDirectoryItem(
            handle=int(sys.argv[1]), url=u,
            listitem=liz, totalItems=total)

    def addDir(self, name, u, mode, infoList=False, infoArt=False):
        name = name.encode("utf-8")
        log('addDir, name = %s' % name)
        liz = xbmcgui.ListItem(name)
        liz.setProperty('IsPlayable', 'false')
        if infoList is False:
            liz.setInfo(type="Video",
                        infoLabels={"mediatype": "video",
                                    "label": name,
                                    "title": name})
        else:
            liz.setInfo(type="Video", infoLabels=infoList)
        if infoArt is False:
            liz.setArt({'thumb': ICON, 'fanart': FANART})
        else:
            liz.setArt(infoArt)
        u = "%s?url=%s&mode=%s&name=%s" % (
            sys.argv[0], urlparse.quote_plus(u),
            str(mode), urlparse.quote_plus(name))
        xbmcplugin.addDirectoryItem(
            handle=int(sys.argv[1]), url=u,
            listitem=liz, isFolder=True)


#web_pdb.set_trace()
params = getParams()
try:
    url = params["url"]
except:
    url = None
try:
    name = urlparse.unquote_plus(params["name"])
except:
    name = None
try:
    mode = params["mode"]
except:
    mode = None
log("Mode: " + str(mode))
log("URL : " + str(url))
log("Name: " + str(name))

if mode is None:
    CC().buildMenu(MAIN_MENU)
elif mode == 'SHOWS':
    CC().listShows(name, url)
elif mode == 'STANDUP':
    CC().listStandUps(name, url)
elif mode == 'GENERIC':
    CC().loadGeneric(name, url)
elif mode == 'SEASON':
    CC().loadShows(name, url, True)
elif mode == 'EPISODES':
    CC().browseItems(name, url)
elif mode == 'PLAY':
    CC().playItem(name, url)


elif mode == 1:
    CC().listStandUps(name, url)
    #CC().browse(name, url)
elif mode == 2:
    CC().buildEpisodes(name, url)
elif mode == 9:
    CC().playVideo(name, url)
elif mode == 12:
    CC().browseShow(name, url)

# web_pdb.set_trace()
# xbmcplugin.setContent(int(sys.argv[1])    , CONTENT_TYPE)
xbmcplugin.addSortMethod(int(sys.argv[1]) , xbmcplugin.SORT_METHOD_UNSORTED)
xbmcplugin.addSortMethod(int(sys.argv[1]) , xbmcplugin.SORT_METHOD_NONE)
xbmcplugin.addSortMethod(int(sys.argv[1]) , xbmcplugin.SORT_METHOD_LABEL)
xbmcplugin.addSortMethod(int(sys.argv[1]) , xbmcplugin.SORT_METHOD_TITLE)
xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=True)
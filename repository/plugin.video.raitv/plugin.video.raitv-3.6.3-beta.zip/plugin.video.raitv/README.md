# plugin.video.raitv

Kodi 18:
use 'master' branch:
https://github.com/maxbambi/plugin.video.raitv/archive/master.zip

Kodi 19:
use 'matrix' branch:
https://github.com/maxbambi/plugin.video.raitv/archive/matrix.zip

# -*- coding: utf-8 -*-
import json
import sys
import time
import xbmc
import xbmcplugin
import xbmcgui


def get_cur_listitem(cont_prefix=""):
    '''gets the current selected listitem details'''
    # Taken from script.skin.helper.service infodialog.py
    if xbmc.getCondVisibility("Window.IsActive(busydialog)"):
        xbmc.executebuiltin("Dialog.Close(busydialog)")
        xbmc.sleep(500)
    dbid = xbmc.getInfoLabel("%sListItem.DBID" % cont_prefix)
    if not dbid or dbid == "-1":
        dbid = xbmc.getInfoLabel("%sListItem.Property(DBID)" % cont_prefix)
        if dbid == "-1":
            dbid = ""
    dbtype = xbmc.getInfoLabel("%sListItem.DBTYPE" % cont_prefix)
    if not dbtype:
        dbtype = xbmc.getInfoLabel("%sListItem.Property(DBTYPE)" % cont_prefix)
    return (dbid, dbtype)


dbID, videoType = get_cur_listitem()
resume = False
abort = False

if dbID and videoType in ['movie', 'episode']:
    jsonQuery = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.Get%sDetails", "params": {"%sid": %s, "properties": ["resume"]}, "id": "1"}' % (videoType.capitalize(), videoType, dbID))
    jsonQuery = json.loads(jsonQuery)
    resumePosition = jsonQuery['result'][videoType + 'details']['resume']['position']

    if resumePosition > 0:
        options = []
        options.append(xbmc.getLocalizedString(12022).format(
            time.strftime("%H:%M:%S", time.gmtime(resumePosition))))
        options.append(xbmc.getLocalizedString(12021))

        selection = xbmcgui.Dialog().contextmenu(options)

        if selection == 0:
            resume = True
        elif selection == -1:
            abort = True


HANDLE = int(sys.argv[1])
PARAM = sys.argv[2].lstrip('?')
item = xbmcgui.ListItem(path=PARAM)
if resume:
    item.setProperty('totaltime', '1')
else:
    item.setProperty('StartPercent', '0')

xbmcplugin.setResolvedUrl(HANDLE, not abort, item)
xbmcplugin.endOfDirectory(handle=HANDLE, succeeded=True)

# -*- coding: utf-8 -*-
import json
import glob
import sys
import time
import xbmc
import xbmcplugin
import xbmcgui


def get_cont_prefix():
    '''gets the container prefix if we're looking at a widget container'''
    widget_container = xbmc.getInfoLabel("Window(Home).Property(SkinHelper.WidgetContainer)")
    if widget_container:
        cont_prefix = "Container(%s)." % widget_container
    else:
        cont_prefix = ""
    return cont_prefix


def get_cur_listitem(cont_prefix=""):
    '''gets the current selected listitem details'''
    # Taken from script.skin.helper.service infodialog.py
    # web_pdb.set_trace()
    if not cont_prefix:
        cont_prefix = get_cont_prefix()
    if xbmc.getCondVisibility("Window.IsActive(busydialog)"):
        xbmc.executebuiltin("Dialog.Close(busydialog)")
        xbmc.sleep(500)
    dbid = xbmc.getInfoLabel("%sListItem.DBID" % cont_prefix)
    if not dbid or dbid == "-1":
        dbid = xbmc.getInfoLabel("%sListItem.Property(DBID)" % cont_prefix)
        if dbid == "-1":
            dbid = ""
    dbtype = xbmc.getInfoLabel("%sListItem.DBTYPE" % cont_prefix)
    if not dbtype:
        dbtype = xbmc.getInfoLabel("%sListItem.Property(DBTYPE)" % cont_prefix)

    fname = xbmc.getInfoLabel("%sListItem.FileNameAndPath" % cont_prefix)
    ext = xbmc.getInfoLabel("%sListItem.FileExtension" % cont_prefix)

    return (dbid, dbtype, fname.replace(ext, '*srt'))


dbID, videoType, fname = get_cur_listitem()

resume = False
# Files.GetFileDetails
if dbID and videoType in ['movie', 'episode']:
    jsonQuery = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.Get%sDetails", "params": {"%sid": %s, "properties": ["resume"]}, "id": "1"}' % (videoType.capitalize(), videoType, dbID))
    jsonQuery = json.loads(jsonQuery)
    resumePosition = jsonQuery['result'][videoType + 'details']['resume']['position']

    if resumePosition > 0:
        options = []
        options.append(xbmc.getLocalizedString(12022).format(
            time.strftime("%H:%M:%S", time.gmtime(resumePosition))))
        options.append(xbmc.getLocalizedString(12021))

        selection = xbmcgui.Dialog().contextmenu(options)

        if selection == 0:
            resume = True
        elif selection == -1:
            sys.exit()


HANDLE = int(sys.argv[1])
PARAM = sys.argv[2].lstrip('?')
item = xbmcgui.ListItem(path=PARAM)
if resume:
    item.setProperty('totaltime', '1')
else:
    item.setProperty('StartPercent', '0')

subs = glob.glob(fname)
if subs is not None:
    item.setSubtitles(subs)

xbmcplugin.setResolvedUrl(HANDLE, True, item)
xbmcplugin.endOfDirectory(handle=HANDLE, succeeded=True)

# -*- coding: utf-8 -*-
import json
import sys
import time
import xbmc
import xbmcplugin
import xbmcgui

HANDLE = int(sys.argv[1])
PARAM = sys.argv[2].lstrip('?')
dbID = xbmc.getInfoLabel('ListItem.DBID') or xbmc.getInfoLabel('Container.ListItem.DBID')
videoType = xbmc.getInfoLabel('ListItem.DBTYPE') or xbmc.getInfoLabel('Container.ListItem.DBTYPE')

jsonQuery = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.Get%sDetails", "params": {"%sid": %s, "properties": ["resume"]}, "id": "1"}' % (videoType.capitalize(), videoType, dbID))
jsonQuery = json.loads(jsonQuery)
resumePosition = jsonQuery['result'][videoType+'details']['resume']['position']
resume = False

if resumePosition > 0:
    options = []
    options.append(xbmc.getLocalizedString(12022).format(
        time.strftime("%H:%M:%S", time.gmtime(resumePosition))))
    options.append(xbmc.getLocalizedString(12021))

    selection = xbmcgui.Dialog().contextmenu(options)

    if selection == 0:
        resume = True
    elif selection == -1:
        xbmcplugin.endOfDirectory(HANDLE)


item = xbmcgui.ListItem(path=PARAM)
if resume:
    item.setProperty('totaltime', '1')
else:
    item.setProperty('StartPercent', '0')

xbmcplugin.setResolvedUrl(HANDLE, True, item)

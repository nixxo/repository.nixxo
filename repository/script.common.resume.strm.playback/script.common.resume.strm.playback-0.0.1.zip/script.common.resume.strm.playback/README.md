# script.common.resume.strm.playback
kodi plugin to workaround the STRM files playback resume not working properly.

Add manually "plugin://script.common.resume.strm.playback/?" as a prefix in your STRM files.